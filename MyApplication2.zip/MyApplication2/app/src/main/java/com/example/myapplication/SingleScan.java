package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

public class SingleScan extends AppCompatActivity {
    TextView textView;
    ProgressDialog progressDoalog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_scan);
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent,10);
        textView = findViewById(R.id.textView);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case 10:
                if(resultCode== RESULT_OK){
                    String path = data.getData().getPath();
                    textView.setText(path);
                }
        }
    }

    public void sinScanS(View view) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage("You are about to start scanning. \n \n Once started, you are unable to stop it. \n\n If any vulnerability found it will pup up. You can clean file in that time.  \n\n Are you sure to start scanning? \n\n");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // dialog.cancel();
                        progressDoalog = new ProgressDialog(SingleScan.this);
                        progressDoalog.setMax(100);
                        progressDoalog.setMessage("Please wait...");
                        progressDoalog.setTitle("Application scanning on progress...");
                        progressDoalog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                        progressDoalog.show();
                        final Handler handle = new Handler() {
                            @Override
                            public void handleMessage(Message msg) {
                                super.handleMessage(msg);
                                progressDoalog.incrementProgressBy(1);
                                progressDoalog.setCancelable(false);
                            }
                        };
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    while (progressDoalog.getProgress() <= progressDoalog
                                            .getMax()) {
                                        Thread.sleep(300);
                                        handle.sendMessage(handle.obtainMessage());
                                        if (progressDoalog.getProgress() == progressDoalog.getMax()) {
                                            progressDoalog.dismiss();

                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                        }).start();

                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}
