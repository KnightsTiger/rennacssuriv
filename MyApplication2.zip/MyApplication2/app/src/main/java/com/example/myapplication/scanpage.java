package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class scanpage extends ListActivity {
    List<String> listfile = new ArrayList<>();
    int vals = 0;
    ProgressDialog progressDoalog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Toast.makeText(this,"done",Toast.LENGTH_LONG);
        super.onCreate(savedInstanceState);

        progressDoalog = new ProgressDialog(scanpage.this);
        progressDoalog.setMax(100);
        progressDoalog.setMessage("Please wait...");
        progressDoalog.setTitle("Application scanning on progress...");
        progressDoalog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDoalog.show();
        final Handler handle = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                progressDoalog.incrementProgressBy(1);
                progressDoalog.setCancelable(false);
            }
        };
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (progressDoalog.getProgress() <= progressDoalog.getMax()) {

                        Thread.sleep(3000);
                        handle.sendMessage(handle.obtainMessage());
                        if (progressDoalog.getProgress() == progressDoalog.getMax()) {
                            progressDoalog.dismiss();

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }).start();


        calldone();


        //setContentView(R.layout.activity_scanpage);
    }

    private void calldone() {
        Toast.makeText(this,"done",Toast.LENGTH_LONG);
        Thread t =new Thread();
        try {
            t.sleep(330);
            File root = new File(Environment.getRootDirectory().getName());
            ListDir(root);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    private void cancelm() {
        Toast.makeText(this,"Scan unsuccess...",Toast.LENGTH_LONG);
    }

    void ListDir(File f){
        File [] files = f.listFiles();
        listfile.clear();
        for(File file:files){
            listfile.add(file.getName());
        }
        ArrayAdapter<String> dir = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,listfile);
        setListAdapter(dir);
    }
}
